#!/bin/bash
NDK=/home/liangcr/Desktop/android-ndk-r14b
SYSROOT=$NDK/platforms/android-14/arch-arm/
TOOLCHAIN=$NDK/toolchains/arm-linux-androideabi-4.9/prebuilt/linux-x86_64
CPU=armv7-a
PREFIX=$(pwd)/android/$CPU
PLATFORM=$NDK/platforms/android-14/arch-arm
CROSS_COMPILE=$TOOLCHAIN/bin/arm-linux-androideabi-
CFLAGS=""
FLAGS="--enable-static  --host=$HOST --target=android --disable-asm "

export CXX="${CROSS_COMPILE}g++ --sysroot=${SYSROOT}"
export LDFLAGS=" -L$SYSROOT/usr/lib  $CFLAGS "
export CXXFLAGS=$CFLAGS
export CFLAGS=$CFLAGS
export CC="${CROSS_COMPILE}gcc --sysroot=${SYSROOT}"
export AR="${CROSS_COMPILE}ar"
export LD="${CROSS_COMPILE}ld"
export AS="${CROSS_COMPILE}gcc"
function build_acc
{
./configure \
    --prefix=$PREFIX \
    --disable-asm \
    --enable-static \
    --enable-shared \
    --target=android \
    --enable-pic \
    --enable-strip \
    --host=arm-linux-androideabi \
$ADDITIONAL_CONFIGURE_FLAG
make clean
make
make install
}
build_acc
